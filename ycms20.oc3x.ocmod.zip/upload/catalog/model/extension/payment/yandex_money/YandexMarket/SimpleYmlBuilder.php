<?php

namespace YandexMoneyModule\YandexMarket;

class SimpleYmlBuilder extends YmlBuilder
{

}
